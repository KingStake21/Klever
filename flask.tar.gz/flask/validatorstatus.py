#!/usr/bin/python3
# asking for user input
#search_word_count = input('Enter the word: ')
elected_status = 'elected'
eligible_status = 'eligible'
jailed_status = 'jailed'
waiting_status = 'waiting'
inactive_status = 'inactive'

# opening text file in read only mode
file = open("validator.txt", "r")

# reading data of the file
read_data = file.read()

# converting data in lower case and the counting the occurrence
word_count = read_data.lower().count(elected_status)
print(f"{elected_status}_nodes {word_count}\n")
word_count = read_data.lower().count(eligible_status)
print(f"{eligible_status}_nodes {word_count}\n")
word_count = read_data.lower().count(jailed_status)
print(f"{jailed_status}_nodes {word_count}\n")
word_count = read_data.lower().count(waiting_status)
print(f"{waiting_status}_nodes {word_count}\n")
word_count = read_data.lower().count(inactive_status)
print(f"{inactive_status}_nodes {word_count}")
