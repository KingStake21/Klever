#!/usr/bin/python3
import re

BLS = '<INSERT BLS KEY HERE>'

#### DO NOT EDIT BELOW ####

copy = False
with open ("validator.txt", "r") as saveoutput:
    for line in saveoutput:
        if line.startswith(BLS):
            copy = True
        if line.startswith('ValidatorStatus'):
            copy = False
        if copy:
            print (line)
