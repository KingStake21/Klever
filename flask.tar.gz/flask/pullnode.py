#!/usr/bin/python3
import re

BLS = '4518ccf31f2407073d858a83e2f39437e0087619eeeec877bd8e3ab7aa5793674ae61756482e1d9c3982148642085d009f5af671346ab7d9f88717c087e7c6d25159e38b54e2323ec97f73aafe8af4cb06822439f24030b8d4af71477447ca88'

copy = False
with open ("validator.txt", "r") as saveoutput:
    for line in saveoutput:
        if line.startswith(BLS):
            copy = True
        if line.startswith('ValidatorStatus'):
            copy = False
        if copy:
            print (line)
