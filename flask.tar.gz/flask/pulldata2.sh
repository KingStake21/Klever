#!/usr/bin/bash

## Ensure appropriate environments are set.

export KLEVER_HOME="$HOME/kever"
export BLS="4518ccf31f2407073d858a83e2f39437e0087619eeeec877bd8e3ab7aa5793674ae61756482e1d9c3982148642085d009f5af671346ab7d9f88717c087e7c6d25159e38b54e2323ec97f73aafe8af4cb06822439f24030b8d4af71477447ca88"

while true
do

#Clear out contents in files	
cat /dev/null > validator_statistics.txt
cat /dev/null > validator.txt
cat /dev/null > $KLEVER_HOME/scripts/flask/templates/klevernode.html
cat /dev/null > node_status.txt
#sleep 1

#Pull metrics from /validator/statistics and /node/status
curl -s http://localhost:8080/validator/statistics >> validator_statistics.txt
curl -s "http://localhost:8080/node/status" >> node_status.txt
#sleep 1

#Convert validator stats to a readable format
python3 rawvalidatorconvert.py > validator.txt

#Convert node stats to a readable format
python3 rawstatusconvert.py > stats.txt

#Gather count of each status (Elected, Eligible, Jailed, Waiting, Invalid)
python3 validatorstatus.py >> $KLEVER_HOME/scripts/flask/templates/klevernode.html

#Gather Node Statistics When Elected
python3 pullnode.py >> $KLEVER_HOME/scripts/flask/templates/klevernode.html

#Gather current node status (Eleced, Eligible, Jailed, Waiting, Invalid)
python3 getstatus.py >> $KLEVER_HOME/scripts/flask/templates/klevernode.html

sed -i 's/klv_peer_type observer/klv_peer_type 0/g' $KLEVER_HOME/scripts/flask/templates/klevernode.html
sed -i 's/klv_peer_type elected/klv_peer_type 1/g' $KLEVER_HOME/scripts/flask/templates/klevernode.html 
sed -i 's/klv_peer_type eligible/klv_peer_type 2/g'  $KLEVER_HOME/scripts/flask/templates/klevernode.html
sed -i 's/klv_peer_type jailed/klv_peer_type 3/g' $KLEVER_HOME/scripts/flask/templates/klevernode.html 
sed -i 's/klv_peer_type waiting/klv_peer_type 4/g' $KLEVER_HOME/scripts/flask/templates/klevernode.html 

#Remove BLS value so that the metrics can all be read
sed -i 's/$BLS/\n/g' $KLEVER_HOME/scripts/flask/templates/klevernode.html
sleep 5

done
